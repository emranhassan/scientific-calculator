# scientific_calculator

<div align="center">
    <img src="/screenshot_1.png" width="400px"</img>
</div>
